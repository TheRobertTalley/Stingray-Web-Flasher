$ErrorActionPreference = "SilentlyContinue"
$appDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$mainUrl = "http://127.0.0.1:8787/"
$statusUrl = "${mainUrl}api/status"

try {
  Invoke-WebRequest -Uri $statusUrl -UseBasicParsing -TimeoutSec 2 | Out-Null
  Start-Process $mainUrl | Out-Null
  exit 0
} catch {
}

$exePath = Join-Path $appDir "StingrayInventoryDesktop.exe"
$args = @("--host", "0.0.0.0", "--port", "8787", "--data-dir", "C:\ProgramData\\Inventory\\data", "--open-browser")
Start-Process -FilePath $exePath -ArgumentList $args -WindowStyle Hidden | Out-Null
