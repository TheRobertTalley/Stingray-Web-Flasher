@echo off
setlocal
set APPDIR=%~dp0
set URL=http://127.0.0.1:8787/
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { Invoke-WebRequest -Uri '%URL%api/status' -UseBasicParsing -TimeoutSec 2 | Out-Null; Start-Process '%URL%'; exit 0 } catch { exit 1 }"
if %ERRORLEVEL% EQU 0 goto :done
"%APPDIR%StingrayInventoryDesktop.exe" --host 0.0.0.0 --port 8787 --data-dir "C:\ProgramData\\Inventory\\data" --open-browser
:done
endlocal
